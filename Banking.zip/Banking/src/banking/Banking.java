/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Brendan Frazer
 */
public class Banking {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan = new Scanner(System.in);
        
        try{
        System.out.println("Please enter 1 to view Standard Bank or select 2 to view Limited Bank: " + "");
        int input = scan.nextInt();
        
        //when the user enters 1 Standard Bank class starts running
        if(input == 1) {
            StandardBank s = new StandardBank();
            
            s.StandardBank();
        }
        
        //when the user enters 1 Limited Bank class starts running
        else if (input == 2) {
            LimitedBank l = new LimitedBank();
            
            l.LimitedBank();
            
            
       }
        
        //When a number other than 1 or 2 is entered this error messae is printed to the command line
        else {
            System.out.println("Please select a valid option");
        }
        
        //catch statement which is initiated when a char is entered instead of an int
        } catch (InputMismatchException e) {
            String k = scan.next();  // clear the users bad input
            System.out.println("ERROR");
            System.out.println("Please enter the number of the option you wish to choose");
            System.out.println();
            
            //restarts the main method when an exception is caught
            main(args);
            
        }
                    
    }
        
        
    }
    
  

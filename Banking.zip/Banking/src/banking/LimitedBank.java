/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Brendan Frazer
 */
public class LimitedBank extends Banking {
    
    public void LimitedBank() {
         
         double currentBalance = 1000.00;
         int Withdraw;
         int Deposit;
         double Overdraft = 100.00;
                
                 //creates  new object  type Scanner
        Scanner scan = new Scanner(System.in);
        
        //While loop that repeats the required operations (shown below) but only when the conditions are true
        while(true)
        {
            
            try{
            System.out.println("Welcome to Limited Bank");
            System.out.println("Enter 1 to View your Current Balance");
            System.out.println("Enter 2 to Deposit money into your Account");
            System.out.println("Enter 3 to Withdraw money from your Account");
            System.out.println("Enter 4 to Exit");
            System.out.print("Enter the number of the option you wish to complete: " + "");
            
            //This scans the input as an int
            int num = scan.nextInt();
            
            //This switch statement allows the many case statements to be executed
            switch(num)
            {
                
                  //The case statement is only executed if it matches the value of the switch (num)
                 //This means if any other value other than a num is entered the switch statement will not execute
                case 1:
                     
                       //This prints out the currentBalance of the user (set at £1000.00
                    System.out.println("Your current Balance is : "+ currentBalance);
                    
                    //This stops the code in this block from running when it matches the value of the switch (num)
                break;
                
                 //The case statement is only executed if it matches the value of the switch (num)
                //This means if any other value other than a num is entered the switch statement will not execute
 
                case 2:
                System.out.print("Enter the amount you wish to deposit: £" + "");
                Deposit = scan.nextInt();
                if(Deposit <= 50){
                
                currentBalance = currentBalance + Deposit;
                System.out.println("The money was successfully deposited into your account");
                }
                else {
                    System.out.println("Your attempt was unsuccessful - the maximum amount that can be desposited is £50");
                    
                }
                
                //This stops the code in this block from running when it matches the value of the switch (num)
                break;
                
                  //The case statement is only executed if it matches the value of the switch (num)
                 //This means if any other value other than a num is entered the switch statement will not execute
 
                case 3:
                
                    System.out.print("Enter the amount of money you wish to withdraw: £" + "");
                Withdraw = scan.nextInt();
                if(Withdraw <= 100){
                    currentBalance = currentBalance - Withdraw;
                    System.out.println("Your withdrawal has been successful");
                }
                else if (Withdraw == currentBalance + Overdraft) {
                    currentBalance = currentBalance - Withdraw + Overdraft;
                    System.out.println("Overdraft used for this withdrawal");
                }
                    
                   
                else {
                    System.out.println("Withdrawl Unsuccessful - the maximum amount that can be withdrawn is £100");
                }
                
                //This stops the code in this block from running when it matches the value of the switch (num)
                break;
                
                 case 4:
                     
                    //This stops to program from running
                    System.exit(0);
                    
                    //This stops the code in this block from running when it matches the value of the switch (num)
                break;
                
                 }
            
             //catch statement which is initiated when a char is entered instead of an int
            } catch (InputMismatchException e) {
                
                //this clears the char that the user entered
            String s = scan.next(); 
            System.out.println("ERROR");
            System.out.println("Please enter the number of the option you wish to choose");
            //this allows the loop to run again after an exception is caught
            continue;
                
            }
        }
    }
    
}

    


    

